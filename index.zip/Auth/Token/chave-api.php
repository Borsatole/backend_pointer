<?php

function chaveApi()
{
    return 'z3X!p@v9&LuGm8T#b7KdQ2Y^cWjN6R4s';
}

?>