<?php

sleep(0);

?>