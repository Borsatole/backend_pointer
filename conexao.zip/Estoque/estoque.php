<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once(dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php');
require_once(dirname(__DIR__, 1) . '/conexao.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

global $pdo;

// Parâmetros de paginação
$pagina = isset($_GET['pagina']) ? (int) $_GET['pagina'] : 1;
$limite = isset($_GET['limite']) ? (int) $_GET['limite'] : 20;
$offset = ($pagina - 1) * $limite;

// Campos de filtro permitidos
$filtrosPermitidos = ['id', 'nome', 'quantidade', 'categoria'];
$filtros = [];
$parametros = [];

// Construção dinâmica dos filtros
foreach ($filtrosPermitidos as $campo) {
    if (isset($_GET[$campo]) && $_GET[$campo] !== '') {
        if ($campo === 'quantidade' || $campo === 'id') {

            if ($campo === 'quantidade') {
                // Quantidade -> busca IGUAL ou MENOR
                $filtros[] = "$campo <= :$campo";
            } else {
                // Id -> busca exata
                $filtros[] = "$campo = :$campo";
            }

            $parametros[$campo] = [
                'valor' => (int) $_GET[$campo],
                'tipo'  => PDO::PARAM_INT
            ];
        } else {
            // Outros campos -> busca parcial com LIKE
            $filtros[] = "$campo LIKE :$campo";
            $parametros[$campo] = [
                'valor' => '%' . $_GET[$campo] . '%',
                'tipo'  => PDO::PARAM_STR
            ];
        }
    }
}


// Monta cláusula WHERE
$where = $filtros ? "WHERE " . implode(" AND ", $filtros) : "";

// Consulta total de registros
$sqlTotal = "SELECT COUNT(*) FROM estoque $where";
$consultaTotal = $pdo->prepare($sqlTotal);
foreach ($parametros as $campo => $dado) {
    $consultaTotal->bindValue(":$campo", $dado['valor'], $dado['tipo']);
}
$consultaTotal->execute();
$totalRegistros = (int) $consultaTotal->fetchColumn();
$totalPaginas   = ceil($totalRegistros / $limite);

// Consulta paginada
$sql = "SELECT * FROM estoque $where ORDER BY id DESC LIMIT :limite OFFSET :offset";

$consulta = $pdo->prepare($sql);
foreach ($parametros as $campo => $dado) {
    $consulta->bindValue(":$campo", $dado['valor'], $dado['tipo']);
}
$consulta->bindValue(':limite', $limite, PDO::PARAM_INT);
$consulta->bindValue(':offset', $offset, PDO::PARAM_INT);
$consulta->execute();

$cadastros = $consulta->fetchAll(PDO::FETCH_ASSOC);

// Retorno JSON
echo json_encode([
    "success"         => true,
    "pagina"          => $pagina,
    "limite"          => $limite,
    "total_registros" => $totalRegistros,
    "total_paginas"   => $totalPaginas,
    "cadastros"       => $cadastros,
]);
