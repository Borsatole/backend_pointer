<?php
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
require_once dirname(__DIR__, 2) . '/middlewares/Autenticacao.php';
require_once dirname(__DIR__, 2) . '/middlewares/lentidao-teste-api.php';
require_once dirname(__DIR__, 2) . '/conexao.php';


// Método permitido
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido"]);
    exit();
}


try {
    global $pdo;

    $sql = "SELECT DISTINCT * FROM estoquecategorias ORDER BY nome ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $categoriasFormatadas = [];
    foreach ($categorias as $categoria) {
        $categoriasFormatadas[] = [
            "id" => $categoria['id'],
            "nome" => $categoria['nome'],


        ];
    }

echo json_encode([
    "success" => true,
    "categorias" => $categoriasFormatadas,
    "total" => count($categoriasFormatadas)
], JSON_UNESCAPED_UNICODE);


} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Erro ao buscar categorias: " . $e->getMessage()
    ]);
}
