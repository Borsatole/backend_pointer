<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once(dirname(__DIR__, 1) . '/middlewares/Autenticacao.php');
require_once(dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$endpoint = $data['endpoint'] ?? "";



if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["erro" => "Método não permitido"]);
    exit(); 
}

if (!$endpoint || !is_string($endpoint) || empty($endpoint)) {
    echo json_encode([
        "success" => false,
        "message" => "Endpoint não informado",
    ]);
}


$usuario = "";
$senha = "";
$dns = "";


function gera_teste($endpoint) {
    global $usuario, $senha, $dns;
    $url = $endpoint;
    $data = [
        "groupName" => "",
        "isMessageFromGroup" => false,
        "messageDateTime" => 1583941522000,
        "receiveMessageAppId" => "com.whatsapp",
        "senderMessage" => "api_cadastro",
        "senderName" => "Tester"
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);


    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === false) {
        echo json_encode([
            "success" => false,
            'message' => 'Erro na requisição. ' . curl_error($ch)
        
        ]);
        exit();
    }

    $responseData = json_decode($response, true);
    if (!isset($responseData['data'][0]['message'])) {
        echo json_encode([
            "success" => false,
            'message' => 'Erro na resposta do servidor. ' . curl_error($ch)
        
        ]);
        exit();
    }

    $message = $responseData['data'][0]['message'];
    $parts = explode('|', $message);
    $usuario = $parts[0];
    $passwordAndDns = explode('?', $parts[1]);
    $senha = $passwordAndDns[0];
    $dns = $passwordAndDns[1] ?? "";
}



// gera_teste($endpoint);
// sleep(4);
echo json_encode([
   
    "success" => true,

    "dadosTeste" => [
        "usuario" => "q2txu1m",
        "senha" => "r4118gb",
        "dns" => "http://nxczs.top"
    ]

    // "dadosTeste" => [
    //     "usuario" => $usuario,
    //     "senha" => $senha,
    //     "dns" => $dns
    // ]
    
],JSON_UNESCAPED_SLASHES);
?>