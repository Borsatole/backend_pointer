<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once dirname(__DIR__, 1) . '/middlewares/Autenticacao.php';
// require_once dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php';
require_once dirname(__DIR__, 1) . '/conexao.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Método permitido
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido"]);
    exit();
}

// Recebe os dados
$data = json_decode(file_get_contents("php://input"), true);

// Validação simples
$id = isset($data['id']) ? (int)$data['id'] : 0;
$nome = trim($data['nome'] ?? '');
$endpoint = trim($data['endpoint'] ?? '');
$dns_propria = trim($data['dns_propria'] ?? '');
$preco = isset($data['preco']) ? (float)$data['preco'] : 0.0;
$status_chatbot = isset($data['status_chatbot']) ? (bool)$data['status_chatbot'] : false;
$status_server = isset($data['status_server']) ? (bool)$data['status_server'] : false;

// Validação obrigatória
if (empty($id)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "ID do servidor não informado"
    ]);
    exit();
}

try {
    global $pdo;
    $sql = "UPDATE servers SET 
                nome = :nome,
                endpoint = :endpoint,
                dns_propria = :dns_propria,
                preco = :preco,
                status_chatbot = :status_chatbot,
                status_server = :status_server
            WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':endpoint', $endpoint);
    $stmt->bindParam(':dns_propria', $dns_propria);
    $stmt->bindParam(':preco', $preco);
    $stmt->bindValue(':status_chatbot', $status_chatbot ? 1 : 0, PDO::PARAM_INT);
    $stmt->bindValue(':status_server', $status_server ? 1 : 0, PDO::PARAM_INT);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    $stmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "Servidor atualizado com sucesso"
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Erro ao atualizar servidor",
        "error" => $e->getMessage()
    ]);
}
