<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once(dirname(__DIR__, 1) . '/middlewares/Autenticacao.php');
require_once(dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php');
require_once(dirname(__DIR__, 1). '/conexao.php');


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

global $pdo;


$consulta = $pdo->prepare("SELECT * FROM servers");
$consulta->execute();
$chatboots = $consulta->fetchAll(PDO::FETCH_ASSOC);


// sleep(2);
echo json_encode([
    "success" => true,
    "chatboots" => $chatboots,
]);