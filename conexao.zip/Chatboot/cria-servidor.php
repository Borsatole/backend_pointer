<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once dirname(__DIR__, 1) . '/middlewares/Autenticacao.php';
require_once dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php';
require_once dirname(__DIR__, 1) . '/conexao.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Método permitido
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido"]);
    exit();
}

// Recebe os dados
$data = json_decode(file_get_contents("php://input"), true);

// Validação simples

$nome = trim($data['nome'] ?? '');
$endpoint = trim($data['endpoint'] ?? '');
$dns_propria = trim($data['dns_propria'] ?? '');
$preco = isset($data['preco']) ? (float)$data['preco'] : 0.0;
$status_chatbot = isset($data['status_chatbot']) ? (bool)$data['status_chatbot'] : false;
$status_server = isset($data['status_server']) ? (bool)$data['status_server'] : false;


// Validação obrigatória
if (empty($nome) || empty($preco)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Nome e preço são obrigatórios"
    ]);
    exit();
}





try {
    global $pdo;

    // Cria a tabela se não existir
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS servers (
            id INT PRIMARY KEY,
            nome VARCHAR(255) NOT NULL,
            endpoint VARCHAR(255) NOT NULL,
            dns_propria VARCHAR(255),
            preco DECIMAL(10,2),
            status_chatbot TINYINT DEFAULT 1,
            status_server TINYINT DEFAULT 1,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Buscar o último id cadastrado e adicionar +1
    $id_atual = $pdo->query("SELECT MAX(id) FROM servers")->fetchColumn() + 1;

    // Inserir o novo servidor
    $sql = "INSERT INTO servers 
    (id, nome, endpoint, dns_propria, preco, status_chatbot, status_server) 
    VALUES (:id, :nome, :endpoint, :dns_propria, :preco, :status_chatbot, :status_server)"; 
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id_atual);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':endpoint', $endpoint);
    $stmt->bindParam(':dns_propria', $dns_propria);
    $stmt->bindParam(':preco', $preco);
    $stmt->bindParam(':status_chatbot', $status_chatbot);
    $stmt->bindParam(':status_server', $status_server);
    $stmt->execute();

    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Servidor criado com sucesso"
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Erro ao criar o servidor",
        "error" => $e->getMessage() // útil para debug
    ]);
}
