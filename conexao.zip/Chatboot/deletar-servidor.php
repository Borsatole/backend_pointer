<?php
require_once dirname(__DIR__, 1) . '/vendor/autoload.php';
require_once dirname(__DIR__, 1) . '/middlewares/Autenticacao.php';
require_once dirname(__DIR__, 1) . '/middlewares/lentidao-teste-api.php';
require_once dirname(__DIR__, 1) . '/conexao.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Método permitido
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido"]);
    exit();
}

// Recebe os dados
$data = json_decode(file_get_contents("php://input"), true);

// Validação simples
$id = isset($data['id']) ? (int)$data['id'] : 0;


// Validação obrigatória
if (empty($id)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "ID do servidor é obrigatório"
    ]);
    exit();
}



try {
    global $pdo;
    $sql = "DELETE FROM servers WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    http_response_code(200);
   echo json_encode([
        "success" => true,
        "message" => "Servidor deletado com sucessos"
    ]); 

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Erro ao deletar o servidor: " . $e->getMessage()
    ]);
}